import React from 'react'
import styled from 'styled-components';
import Visual from "../../components/Section/Visual";

const Home = () => {
    
    return (
        <Container>
        </Container>
    )
}


const Container = styled.div`
    
`;

export default Home;