import React from 'react';
import styled from 'styled-components';
import SideMenuContainer from "../../container/SideMenuContainer";
const SideMenu = () => {

    return(
        <Container>
            <SideMenuContainer/>
        </Container>
    )

}

const Container = styled.div`
    
    
    
`

export default SideMenu;