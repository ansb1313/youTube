import React from 'react';
import styled from 'styled-components';
import {SectionContainer} from "../Layout/Layout.Styled";

const Contact = () => {

    return(

        <Container>

        </Container>

    )

}

const Container = styled(SectionContainer)`



`

export default Contact;