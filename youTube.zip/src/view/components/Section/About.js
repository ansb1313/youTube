import React from 'react';
import styled from 'styled-components';
import {SectionContainer} from "../Layout/Layout.Styled";

const About = () => {

    return(

        <Container>

        </Container>

    )

}

const Container = styled(SectionContainer)`
    
    
    
`

export default About;