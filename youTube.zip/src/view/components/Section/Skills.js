import React from 'react';
import styled from 'styled-components';
import {SectionContainer} from "../Layout/Layout.Styled";

const Skills = () => {

    return(

        <Container>

        </Container>

    )

}

const Container = styled(SectionContainer)`



`

export default Skills;